@extends('layouts.admin')
@section('content')

   <script type="text/javascript" src="{{URL::asset('ckeditor/ckeditor.js')}}"></script>
  <!-- CONTENT -->
  <div class="main-content">
<h1>Create Room</h1>
{{ Form::open(array('route' => 'rooms.store','files'=>true)) }}
 <div class="form-group">
        {{ Form::label('name room', 'name room:') }}
        {{ Form::text('name_room') }}
    </div>
    <div class="form-group">
        {{ Form::label('adult capacity', 'adult capacity:') }}
        {{ Form::text('adult_capacity') }}
    </div>
     <div class="form-group">
        {{ Form::label('child capacity', 'child capacity:') }}
        {{ Form::text('child_capacity') }}
    </div>
   <div class="form-group">
        {{ Form::label('facility', 'facility:') }}
        {{ Form::textarea('facility', null, array(
            'class' => 'ckeditor',
            'rows' => 10,
        )) }}
    </div>
  <div class="form-group">
      {{ Form::label('count', 'count')}}
      {{ Form::text('count')}}

  </div>
     <div class="form-group">
  {{ Form::label('image','File',array('id'=>'','class'=>'')) }}
  {{ Form::file('image','',array('id'=>'','class'=>'')) }}
    </div>
   <div class="form-group">
        {{ Form::submit('Save', array('class' => 'btn btn-primary')) }}
    </div>

{{ Form::close() }}
@if ($errors->any())
 <div class="form-group">
    {{ implode('', $errors->all('<li class="error">:message</li>')) }}
</div>
    <?php echo Form::close() ?>
</div>



    </div> <!-- main-content -->
@endif
@stop