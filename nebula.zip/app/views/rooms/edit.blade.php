@extends('layouts.admin')
@section('content')

  <!-- CONTENT -->
     <script type="text/javascript" src="{{URL::asset('ckeditor/ckeditor.js')}}"></script>

  <div class="main-content">
<h1>Edit Room</h1>
<!--{{ Form::model($room, array('method' => 'PATCH',  'route' =>array('rooms.update', $room->id))) }} -->
{{ Form::model($room, array('method' => 'PATCH',  'route' =>array('rooms.update', $room->id) , 'files'=>true)) }} 
<!--{{ Form::model($room, array('method' => 'PATCH','route' => 'rooms.update', $room->id, 'files'=>true)) }}-->
 <div class="form-group">
        {{ Form::label('name room', 'name room:') }}
        {{ Form::text('name_room') }}
    </div>
   <div class="form-group">
        {{ Form::label('adult capacity', 'adult capacity:') }}
        {{ Form::text('adult_capacity') }}
    </div>
     <div class="form-group">
        {{ Form::label('child capacity', 'child capacity:') }}
        {{ Form::text('child_capacity') }}
    </div>
   <div class="form-group">
    {{ Form::label('facility', 'facility:') }}
        {{ Form::textarea('facility', null, array(
            'class' => 'ckeditor',
            'rows' => 10,
        )) }}
    </div>
     <div class="form-group">
 <div class="form-group">
      {{ Form::label('count', 'count')}}
      {{ Form::text('count')}}

  </div>

<img src="{{ asset("uploads/".$room->image ) }}">
  {{ Form::label('image','File',array('id'=>'','class'=>'')) }}
  {{ Form::file('image','',array('id'=>'','class'=>'')) }}
    <li>
        {{ Form::submit('Update', array('class' => 
                 'btn btn-warning'))}}
        {{ link_to_route('rooms.index', 'Cancel', $room->
                  id,array('class' => 'btn btn-danger')) }}
</div>

 

{{ Form::close() }}
@if ($errors->any())
 <div class="form-group">
    {{implode('',$errors->all('<li class="error">:message</li>'))}}
</div>
</div>
@endif
@stop