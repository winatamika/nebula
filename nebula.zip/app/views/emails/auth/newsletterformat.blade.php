<div style="width: 500px;margin: 0 auto;">

	<div style="padding: 15px 10px;background-color: #15063a;color: #fff;text-align: justify;">
		
		<h1 style="font-size: 20px;color: #fff;line-height: 22px;">{{ $subject }}</h1>
	
	</div> <!-- header -->

	<div style="padding: 15px 10px; color: #2f3134;">

		Hallo, <strong>{{ $name }}</strong>,

		<br>

		{{ $content }}

	</div> <!-- content -->
	
	<div style="background-color: #15063a;color: #fff;text-align: justify;">

		<p>{{ $hotel }}</p>
		<p>{{ $address }}</p>

	</div>

</div> <!-- container email -->

