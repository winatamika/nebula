@extends('layouts.theme.default.orange')

@section('content')

	<div class="main-content">
    <h2>Booking Details</h2>   
    <table class="table table-striped table-bordered">
    	<tr>
    		<td colspan="4"><center><b>Your Booking Details</b></center></td>
    	</tr>
    	<tr>
    		<td><b>Checkin Date</b></td>
    		<td><b>Checkout Date</b></td>
    		<td><b>Total Night</b></td>
    		<td><b>Total Room</b></td>

    	</tr>
    	<tr>
    		<td><?=$_SESSION['sv_checkindate'] ?></td>
    		<td><?=$_SESSION['sv_checkoutdate']  ?></td>
    		<td><?=$_SESSION['sv_nightcount'] ?></td>
    		<td>{{$totalroom}}</td>
    	</tr>
    	 <tr>
    		<td><b>Number of Room</b></td>
    		<td><b>Room Type</b></td>
    		<td><b>Adult Occupancy</b></td>
    		<td><b>Gross Total</b></td>
    	</tr>
    	
         <?php $i=0; ?>
              @foreach ($roomsList as $room)
                <tr>
    		<td><?php echo $no_of_room[$i];?></td>
    		<td>{{ $room->name_room }}</td>
    		<td>{{ $room->adult_capacity }}</td>
    		<td><?php echo $currency_symbol.number_format($totalgross[$i], 2 , '.', ',') ?></td>
             <?php $i++; ?>
             </tr>
              @endforeach
        
    	
        <tr>
            <td colspan="3" align="right"><b>Subtotal</b></td>
            <td><b>{{$currency_symbol.number_format($totalprice, 2 , '.', ',')}}</b></td>
        </tr>
    	<tr>
    		<td colspan="3" align="right"><b>Grand Total (include tax)</b></td>
    		<td><b>{{$currency_symbol.number_format($totalprice, 2 , '.', ',')}}</b></td>
    	</tr>

    </table>
	


        <h2>Customer Details</h2>      
        <form action="{{ URL::Route('booking-save') }}" class="form-horizontal has-success has-feedback" role="form" method="post">
          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Email Address</label>
            <div class="col-sm-10">
             <input type="text" name="email_name" class="form-control" id="inputEmail3" placeholder="Email Name" value="">
        
            </div>
          </div>
          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">First Name</label>
            <div class="col-sm-10">
              <input type="text" name="first_name" class="form-control" id="inputEmail3" placeholder="First Name" value="">
            
            </div>
          </div>
          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Last Name</label>
            <div class="col-sm-10">
              <input type="text" name="last_name" class="form-control" id="inputEmail3" placeholder="Last Name" value="">
          
            </div>
          </div>
          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Address</label>
            <div class="col-sm-10">
              <input type="text" name="address" class="form-control" id="inputEmail3" placeholder="Address" value="">
            
            </div>
          </div>
            <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">City</label>
            <div class="col-sm-10">
              <input type="text" name="city" class="form-control" id="inputEmail3" placeholder="City" value="">
          
            </div>
          </div>
            <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">State</label>
            <div class="col-sm-10">
              <input type="text" name="state" class="form-control" id="inputEmail3" placeholder="State" value="">
          
            </div>
          </div>
          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Country</label>
            <div class="col-sm-10">
              <input type="text" name="country" class="form-control" id="inputEmail3" placeholder="Country" value="">
          
            </div>
          </div>
          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Zip / Post Code</label>
            <div class="col-sm-10">
              <input type="text" name="zip" class="form-control" id="inputEmail3" placeholder="Zip" value="">
            
            </div>
          </div>
          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Phone Number</label>
            <div class="col-sm-10">
              <input type="text" name="phone" class="form-control" id="inputEmail3" placeholder="Phone" value="">
          
            </div>
          </div>
          <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Fax</label>
            <div class="col-sm-10">
              <input type="text" name="fax" class="form-control" id="inputEmail3" placeholder="Fax" value="">
            
            </div>
          </div>

                <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Payment Gateway</label>
            <div class="col-sm-10">
                   @foreach ($payment_gateway as $gateway)
             <input type="radio" name="gateway[]" value="{{ $gateway->gateway_name}}">{{ $gateway->gateway_name}}<br>
             @endforeach
            </div>
          </div>

             <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Any additional requests :</label>
            <div class="col-sm-10">
              <textarea name="request" class="form-control" id="inputEmail3" placeholder="request" value="">
            </textarea>
            </div>
          </div>



          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" class="btn btn-default">Confirm And Checkout</button>
                {{ Form::token() }}
            </div>
          </div>
        </form>

    </div>

@stop