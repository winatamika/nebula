@extends('layouts.admin')

@section('content')

	<!-- CONTENT -->
	<div class="main-content">
		
		<h2>Themes</h2>
		<form action="{{ URL::Route('theme-change') }}" method="post" role="form">
			<select class="form-control" id="themes" name="themes">
			  <option value="1">Default</option>
			  <option value="2">Custome</option>
			</select>
			
			<hr>
			
			<div id="default">
				<div class="row">
					<div class="col-sm-12">
						<h4>Default Theme</h4>
						<textarea class="form-control" name="default" rows="10"></textarea>
					</div>
				</div> <!-- row -->
			</div> <!-- default -->

			<div id="custome">
				<div class="row">
					<!-- <div class="col-sm-4">
						<div class="form-group">
						    <label for="exampleInputEmail1">Theme Name</label>
						    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter theme name" name="themename">
						  </div>
					</div> -->
					<div class="col-sm-12">
						<h4>Custome Theme</h4>
						<textarea class="form-control" name="custome" rows="10"></textarea>
					</div>
					
				</div>
			</div> <!-- custome -->
			<br>

			 <button type="submit" class="btn btn-default">Update</button>
				{{ Form::token() }}
		</form>

	</div> <!-- main-content -->

@stop