<?php

class Emails extends \Eloquent {
	protected $fillable = [];

	protected $table = 'email_contents';
}