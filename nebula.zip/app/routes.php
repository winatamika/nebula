<?php

Route::resource('sessions', 'SessionsController');

// Authenticated Group
Route::group(array('before' => 'auth'), function() {

	Route::get('admin', ['as' => 'admin', function()
	{
		return View::make('admin');
	}]);

	// logout
	Route::get('logout', array(
		'as' => 'logout',
		'uses' => 'SessionsController@destroy'
	));

	// ACCOUNT LIST
	Route::get('account', array(
		'as' => 'account',
		'uses' => 'SessionsController@accountList'
	));

	// ACCOUNT CREATE
	Route::get('account/create', array(
		'as' => 'create',
		'uses' => 'SessionsController@create'
	));

	// ACCOUNT EDIT
	Route::get('account/edit/{id}', array(
		'as' => 'account-edit',
		'uses' => 'SessionsController@edit'
	));
	
	// CSRF protection group
	Route::group(array('before' => 'csrf'), function() {

		// ACCOUNT CREATE
		Route::post('account/create', array(
			'as' => 'create-post',
			'uses' => 'SessionsController@createPost'
		));

		// ACCOUNT EDIT
		Route::post('account/edit', array(
			'as' => 'account-edit-post',
			'uses' => 'SessionsController@editPost'
		));

		// ACCOUNT DEL
		Route::post('account/del', array(
			'as' => 'account-del',
			'uses' => 'SessionsController@del'
		));

		// CHANGE PASS
		Route::post('account/change-password', array(
			'as' => 'account-change-password-post',
			'uses' => 'SessionsController@changepass'
		));

		// Payment EDIT
		Route::post('payment-gateway/edit', array(
			'as' => 'payment-edit-post',
			'uses' => 'PaymentController@update'
		));

		// config
		Route::post('configure', array(
			'as' => 'configure-save',
			'uses' => 'ConfigureController@update'
		));

		// Profile
		Route::post('profile', array(
			'as' => 'profile-save',
			'uses' => 'ProfileController@update'
		));

		// customer
		Route::post('customer/edit', array(
			'as' => 'customer-edit-post',
			'uses' => 'CustomerController@update'
		));

		// emailcontent
		Route::post('email/edit', array(
			'as' => 'email-edit-post',
			'uses' => 'EmailController@update'
		));

		// newsletter
		Route::post('newsletter', array(
			'as' => 'newsletter-send',
			'uses' => 'NewsletterController@update'
		));

		// themes
		Route::post('themes', array(
			'as' => 'theme-change',
			'uses' => 'ThemesController@update'
		));


	});

	// CHANGE PASS
	Route::get('account/change-password', array(
		'as' => 'account-change-password',
		'uses' => 'SessionsController@change'
	));

	// Payment 
	Route::get('payment-gateway', array(
		'as' => 'payment-gateway',
		'uses' => 'PaymentController@show'
	));
	
	// Payment EDIT
	Route::get('payment-gateway/edit/{id}', array(
		'as' => 'payment-edit',
		'uses' => 'PaymentController@edit'
	));

	// config
	Route::get('configure', array(
		'as' => 'configure',
		'uses' => 'ConfigureController@show'
	));

	// Profile
	Route::get('profile', array(
		'as' => 'profile',
		'uses' => 'ProfileController@show'
	));

	// customer
	Route::get('customer', array(
		'as' => 'customer',
		'uses' => 'CustomerController@show'
	));

	// customer
	Route::get('customer/edit/{id}', array(
		'as' => 'customer-edit',
		'uses' => 'CustomerController@edit'
	));

	// newsletter
	Route::get('newsletter', array(
		'as' => 'newsletter',
		'uses' => 'NewsletterController@show'
	));

	// emailcontent
	Route::get('email', array(
		'as' => 'email',
		'uses' => 'EmailController@show'
	));

	// emailcontent
	Route::get('email/edit/{id}', array(
		'as' => 'email-edit',
		'uses' => 'EmailController@edit'
	));

	// calendar
	Route::get('calendar', array(
		'as' => 'calendar',
		'uses' => 'CalendarController@show'
	));

	// themes
	Route::get('themes', array(
		'as' => 'themes',
		'uses' => 'ThemesController@show'
	));

	// mika 
	Route::get('priceplan',array(
		'as' => 'priceplan',
		'uses' => 'priceplanController@index'
	));
	Route::get('processprice',array(
		'uses' => 'priceplanController@show'
	));

	Route::resource('priceplan','PriceplanController');
		
	Route::resource('rooms','RoomController');
	

}); // Authenticated Group

// SEARCH 
Route::get('/', array(
	'as' => 'index',
	'uses' => 'SearchController@index'
));

// SEARCH 
Route::post('booking-search', array(
	'as' => 'booking-search',
	'uses' => 'SearchController@search'
));

Route::post('booking-detail',array(
	'as' => 'booking-detail',
	'uses' => 'DetailsController@index'
));

Route::post('booking-detail',array(
	'as' => 'booking-detail',
	'uses' => 'DetailsController@index'
));

Route::post('booking-save',array(
	'as' => 'booking-save',
	'uses' => 'DetailsController@save'
));

// Unautheticated Group
Route::group(array('before' => 'guest'), function() {

	// CSRF protection group
	Route::group(array('before' => 'csrf'), function() {

		// sign in
		Route::post('login', array(
			'as' => 'store',
			'uses' => 'SessionsController@store'
		));
		
	});

	// sign in
	Route::get('login', array(
		'as' => 'login',
		'uses' => 'SessionsController@index'
	));
	
});

