<?php

class DetailsController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */


	public function index()
	{
		// 
		$rooms = Input::get('room_id');
		$count = Input::get('roomcount');
		$total = Input::get('total');
		$totalroom = 0;
		$totalprice = 0;
		$theroom = count($count);
		$getconfig = $this->getconfig();
		$currency_symbol = $getconfig['conf_currency_symbol'];
		$this->setMySessionVars();

		for($i = 0; $i < $theroom; $i++){
				if($count[$i] > 0){
					$no_of_room[] = $count[$i];
					$totalroom = $totalroom + $count[$i];
					$totalgross[] = $total[$i] * $count[$i]; 
					$totalprice = $totalprice + ($total[$i] * $count[$i]);
					$roomid[] = $rooms[$i];	
				}
		}

		//select * where id room

			$getroomid = implode(",",$roomid); 
		  	$roomsList = DB::select('select * from rooms where id in ('.$getroomid.') ;');
		  	$payment_gateway = Payment::where('enabled', '=', '1'  )->get();
				
				return View::make('frontend.details',compact('roomsList','payment_gateway', 'no_of_room', 'totalgross', 'totalroom', 'totalprice', 'currency_symbol'));
        			

	}
 
private function setMySessionVars(){
		session_start();
		$_SESSION['sv_checkindate'];
		$_SESSION['sv_checkoutdate'] ;
		$_SESSION['sv_nightcount'];	
		$_SESSION['sv_adultCap'];
		$_SESSION['sv_childCap'];
}

	private function getconfig(){
		$getconfigs = Setting::distinct()->select('conf_key as key', 'conf_value as value')->get();
		foreach ($getconfigs as $getconfig) {

			if($getconfig->key){
				if($getconfig->value){
					$config[$getconfig->key] = $getconfig->value;
				}else{
					$config[$getconfig->key] = false;
				}
			}
		}

		return $config;
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */

	public function save(){

	}


	public function create()
	{
		//
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		//
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}


}
