<?php

class ThemesController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 * GET /themes
	 *
	 * @return Response
	 */
	public function index()
	{
		//
	}

	/**
	 * Show the form for creating a new resource.
	 * GET /themes/create
	 *
	 * @return Response
	 */
	public function create()
	{
		//
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /themes
	 *
	 * @return Response
	 */
	public function store()
	{
		//
	}

	/**
	 * Display the specified resource.
	 * GET /themes/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show()
	{
		return View::make('admin.themes');
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /themes/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /themes/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update()
	{

		$themes		= Input::get('themes');
		$default	= Input::get('default');
		$custome	= Input::get('custome');

		if($themes==1){
			$query = DB::table('themes')
			            ->where('id', 1)
			            ->update(array('theme' => $themes, 'default' => $default));

		}else{
			$query = DB::table('themes')
			            ->where('id', 1)
			            ->update(array('theme' => $themes, 'custome' => $custome));

		}

		if($query) {
			return  Redirect::route('themes')
					->with('flash_message', 'Update Themes, Success!');
		}else{
			return  Redirect::back()
					->with('flash_message', 'Please try again');
		}
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /themes/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}

}