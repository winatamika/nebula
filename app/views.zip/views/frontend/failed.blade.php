@extends('layouts.theme.using')

@section('content')
	<div class="main-content">
	<div class="alert alert-danger" role="alert" align="center">
			booking failed !
		 </div>

		 <div class="alert alert-warning" role="alert">{{ $messages }}</div>
	
</div>
@stop