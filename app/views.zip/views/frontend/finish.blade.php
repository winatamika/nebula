@extends('layouts.theme.using')

@section('content')
	<div class="main-content">
		<div class="alert alert-success" role="alert" align="center">
			booking finish 
		 </div>

</div>
@stop